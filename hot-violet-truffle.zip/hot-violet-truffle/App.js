import React, { useState } from "react";
import { View, Text, Button, StyleSheet } from "react-native";
//import * as ScreenOrientation from "expo-screen-orientation";

export default function App() {
  const [isLocked, setIsLocked] = useState(false);
  const [isPortrait, setIsPortrait] = useState(true);

  const toggleOrientation = async () => {
    if (isLocked) return; // Prevent changing if locked

    if (isPortrait) {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE);
    } else {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT);
    }
    setIsPortrait(!isPortrait);
  };

  const lockOrientation = async () => {
    if (isPortrait) {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    } else {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE);
    }
    setIsLocked(true);
  };

  const unlockOrientation = async () => {
    await ScreenOrientation.unlockAsync(); // Unlocks orientation
    setIsLocked(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>
        Current Mode: {isPortrait ? "Portrait" : "Landscape"}
      </Text>
      <Button title="Switch Orientation" onPress={toggleOrientation} disabled={isLocked} />
      <Button title="Lock Orientation" onPress={lockOrientation} />
      <Button title="Unlock Orientation" onPress={unlockOrientation} disabled={!isLocked} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  text: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 20,
  },
});